package com.part1;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;

public class Main {

    public static void main(String[] args) throws IOException {

        // Image 1 -> Marginal
        // Image 2 -> Norm Based
        // Image 3 -> Bitmix
        // Image 4 -> Lexical
        // Image 5 -> Marginal
        // Image 6 -> Bitmix
        // Image 7 -> Marginal
        // Image 8 -> Lexical
        // Image 9 -> Maginal
        // Image 10 -> Norm Based

        for (int i = 1; i <= 10; i++) {
            BufferedImage image = ImageIO.read(new File("Salted_Images/"+i+".jpg"));
            VectorMedian vector = null;
            double mse = 0.0;
            if (i % 4 == 0){  // images: {4 - 8} lexical
                vector = new VectorMedian(image,"Lexical",i-1); // filter size = 3 - 7
                BufferedImage vectorImage = vector.Vector();
                ImageIO.write(vectorImage, "jpg", new File( "Part1_Results/"+i+"_Lexical.jpg"));
                mse = MSE(image, vectorImage);
                System.out.println(i+" Lexical image MSE " + mse);
            }
            else if (i % 3 == 0) // images: {3 - 6 - 9}  bitmix
            {
                int filter = i;
                if (filter>3)
                    filter = (int) Math.ceil(filter / 2);
                vector = new VectorMedian(image,"Bitmix",filter);  // filter size = 3 - 3 - 5
                BufferedImage vectorImage = vector.Vector();
                ImageIO.write(vectorImage, "jpg", new File( "Part1_Results/"+i+"_Bitmix.jpg"));
                mse = MSE(image, vectorImage);
                System.out.println(i+" Bitmix image MSE " + mse);
            }
            else if (i % 2 == 0) { // images: {2 - 10}  norm
                vector = new VectorMedian(image,"NormBased",5);  // filter size = 5 - 5
                BufferedImage vectorImage = vector.Vector();
                ImageIO.write(vectorImage, "jpg", new File( "Part1_Results/"+i+"_NormBased.jpg"));
                mse = MSE(image, vectorImage);
                System.out.println(i+" Norm Based image MSE " + mse);
            }
            else  // images: {1 - 5 - 7 - 9} marginal
            {
                int filter = i;
                if (filter<3)
                    filter = 3;
                BufferedImage marginalImage = new MarginalMedian().marginalStrategy(image,filter);  // filter size 1 - 5 - 7 - 9
                ImageIO.write(marginalImage,"jpg",new File("Part1_Results/"+i+"_Marginal.jpg"));
                mse = MSE(image, marginalImage);
                System.out.println(i+" Marginal image MSE " + mse);
            }

        }

    }

    public static double MSE(BufferedImage in, BufferedImage out)
    {
        double error = 0.0;
        int width = in.getWidth();
        int height = in.getHeight();
        int size = width * height;

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                int pixel = in.getRGB(i, j) - out.getRGB(i,j);
                error += Math.pow(pixel, 2);
            }
        }

        error = error / size;
        return error;
    }
}

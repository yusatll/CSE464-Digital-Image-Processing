package com.part1;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static java.awt.image.BufferedImage.TYPE_3BYTE_BGR;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public class VectorMedian {
    private BufferedImage image;
    private String OrderingType;
    private int filter_size;
    VectorMedian(BufferedImage image,String OrderingType, int filter_size){
        this.image = image;
        this.filter_size = filter_size;
        this.OrderingType = OrderingType;
    }

    public BufferedImage Vector() throws IOException {

        BufferedImage vectorImage = new BufferedImage(image.getWidth(),image.getHeight(),TYPE_3BYTE_BGR);

        int width = image.getWidth();
        int height = image.getHeight();
        Color[] orderpixels = new Color[filter_size * filter_size];

        for (int i = 0; i < width - filter_size; i++) {
            for (int j = 0; j < height - filter_size; j++) {
                for (int filteri = 0; filteri < filter_size; filteri++) {
                    for (int filterj = 0; filterj < filter_size; filterj++) {
                        Color c = new Color(image.getRGB(i + filteri, j + filterj));
                        orderpixels[filteri * filter_size + filterj] = c;
                    }
                }

                sortColorPixels(orderpixels,OrderingType);

                int t = (filter_size * filter_size - 1) / 2;
                vectorImage.setRGB(i + (filter_size-1)/2, j+ (filter_size-1)/2, orderpixels[t].getRGB());
            }
        }

        removePadding(vectorImage, width, height, filter_size);

//        System.out.println(OrderingType + " Image Created.");
        return vectorImage;
    }

    private void removePadding(BufferedImage img, int w, int h, int filter)
    {
        BufferedImage out = new BufferedImage(w, h, TYPE_3BYTE_BGR);

        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                if (i <= (filter - 1)/2 || i >= img.getWidth())
                    out.setRGB(i,j,0);
                else if (j <= (filter - 1)/2 || j >= img.getHeight())
                    out.setRGB(i,j,0);
                else
                    out.setRGB(i,j, img.getRGB(i - (filter - 1)/2,j - (filter - 1)/2));

            }
        }
    }

    private int LexicographicalOrdering(Color c1, Color c2)
    {
        int red1 = c1.getRed();
        int green1 = c1.getGreen();
        int blue1 = c1.getBlue();

        int red2 = c2.getRed();
        int green2 = c2.getGreen();
        int blue2 = c2.getBlue();

        if (red1 > red2)
            return 1;
        else if (red1 < red2 )
            return -1;

        if (green1 > green2)
            return 1;
        else if (green1 < green2 )
            return -1;

        if (blue1 > blue2)
            return 1;
        else if (blue1 < blue2 )
            return -1;
        else
            return 0;
    }


    private int NormBasedOrdering(Color obj1, Color obj2) {
        int red1 = obj1.getRed();
        int green1 = obj1.getGreen();
        int blue1 = obj1.getBlue();

        int red2 = obj2.getRed();
        int green2 = obj2.getGreen();
        int blue2 = obj2.getBlue();

        double cal1 = sqrt(pow(red1,2) + pow(green1,2) + pow(blue1,2));
        double cal2 = sqrt(pow(red2,2) + pow(green2,2) + pow(blue2,2));

        if (cal1 > cal2)
            return 1;
        else if(cal1 < cal2)
            return -1;
        else
            return 0;
    }

    private void sortColorPixels(Color [] pixels, String ordering)
    {
        for (int i = 0; i < pixels.length - 1; i++) {
            for (int j = 0; j < pixels.length - 1 - i; j++) {
                int compare = -5;
                if (ordering.equals("lexical") || ordering.equals("lexicographical") || ordering.equals("Lexical")) {
                    compare = LexicographicalOrdering(pixels[j+1], pixels[j]);
                } else if (ordering.equals("bitmix") || ordering.equals("Bitmix"))
                    compare = BitmixOrdering(pixels[j+1], pixels[j]);
                else if (ordering.equals("NormBased") || ordering.equals("normbased"))
                    compare = NormBasedOrdering(pixels[j+1], pixels[j]);

                if (compare == 1) {
                    Color temp = pixels[j + 1];
                    pixels[j + 1] = pixels[j];
                    pixels[j] = temp;
                }
            }
        }

    }

    private int BitmixOrdering(Color c1, Color c2)
    {
        int cmp1=0, cmp2=0;

        int red1 = c1.getRed();
        int green1 = c1.getGreen();
        int blue1 = c1.getBlue();

        int red2 = c2.getRed();
        int green2 = c2.getGreen();
        int blue2 = c2.getBlue();

        for (int i = 7; i > 0; i--)
        {
            cmp1 |= (red1 >> i) & 1;
            cmp1 = cmp1 << 1;
            cmp1 |= (green1 >> i) & 1;
            cmp1 = cmp1 << 1;
            cmp1 |= (blue1 >> i) & 1;
            cmp1 = cmp1 << 1;

            cmp2 |= (red2 >> i) & 1;
            cmp2 = cmp2 << 1;
            cmp2 |= (green2 >> i) & 1;
            cmp2 = cmp2 << 1;
            cmp2 |= (blue2 >> i) & 1;
            cmp2 = cmp2 << 1;
        }

        if(cmp1 > cmp2)
            return 1;
        else if(cmp1 < cmp2)
            return -1;
        else return 0;
    }

    private int getBit(int n, int k)
    {
        return (n >> k) & 1;
    }
    public int compareBit(Color c1, Color c2)
    {
        int RGB1 = 0, RGB2 = 0;

        int r1 = c1.getRed();
        int g1 = c1.getGreen();
        int b1 = c1.getBlue();

        int r2 = c2.getRed();
        int g2 = c2.getGreen();
        int b2 = c2.getBlue();

        for (int i = 7; i > 0; --i)
        {
            RGB1 |= getBit(r1,i);
            RGB1 <<= 1;
            RGB1 |= getBit(g1,i);
            RGB1 <<= 1;
            RGB1 |= getBit(b1,i);
            RGB1 <<= 1;

            RGB2 |= getBit(r2,i);
            RGB2 <<= 1;
            RGB2 |= getBit(g2,i);
            RGB2 <<= 1;
            RGB2 |= getBit(b2,i);
            RGB2 <<= 1;
        }
        if (RGB1 > RGB2)
            return 1;
        else if (RGB1 < RGB2)
            return -1;
        else
            return 0;
    }


//    private void BitmixOrdering(Color [] pixels)
//    {
//        for (int i = 0; i < pixels.length - 1; i++) {
//            for (int j = 0; j < pixels.length - 1 - i; j++) {
//                if (compareBitmix(pixels[j+1], pixels[j]) == 1) {
//                    Color temp = pixels[j + 1];
//                    pixels[j + 1] = pixels[j];
//                    pixels[j] = temp;
//                }
//            }
//        }
//    }

//    private void NormBasedOrdering(Color [] pixels)
//    {}

    //    private void LexicographicalOrdering(Color [] pixels)
//    {
//        for (int i = 0; i < pixels.length - 1; i++) {
//            for (int j = 0; j < pixels.length - 1 - i; j++) {
//                if (compareLexical(pixels[j+1], pixels[j]) == 1) {
//                    Color temp = pixels[j + 1];
//                    pixels[j + 1] = pixels[j];
//                    pixels[j] = temp;
//                }
//            }
//        }
//    }
}

package com.part1;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import static java.awt.image.BufferedImage.TYPE_3BYTE_BGR;

public class MarginalMedian {

    public BufferedImage marginalStrategy(BufferedImage img, Integer filter_size) throws IOException {
        img = zeroPadding(img,filter_size);
        BufferedImage marginalImage = new BufferedImage(img.getWidth(),img.getHeight(),TYPE_3BYTE_BGR);
        ImageIO.write(img,"jpg", new File("Zero_Padding.jpg"));

        int[] red = new int[filter_size * filter_size];
        int[] green = new int[filter_size * filter_size];
        int[] blue = new int[filter_size * filter_size];

        int width = img.getWidth();
        int height = img.getHeight();

        for (int i = 0; i < width - filter_size; i++) {
            for (int j = 0; j < height - filter_size; j++) {
                for (int filteri = 0; filteri < filter_size; filteri++) {
                    for (int filterj = 0; filterj < filter_size; filterj++) {
                        Color c = new Color(img.getRGB(i + filteri, j + filterj));
                        red[filteri * filter_size + filterj] = c.getRed();
                        green[filteri * filter_size + filterj] = c.getGreen();
                        blue[filteri * filter_size + filterj] = c.getBlue();
                    }
                }
                Arrays.sort(red);
                Arrays.sort(green);
                Arrays.sort(blue);
                int t = (filter_size * filter_size - 1) / 2;
                marginalImage.setRGB(i + (filter_size-1)/2, j+ (filter_size-1)/2, new Color(red[t], green[t], blue[t]).getRGB());
            }
        }
//        System.out.println("Marginal Image Created.");
        return marginalImage;
    }

    public BufferedImage zeroPadding(BufferedImage img, Integer filter)
    {
        int width = img.getWidth();
        int height = img.getHeight();
        // System.out.println("Zero Pedding");

        BufferedImage out = new BufferedImage(width + filter - 1, height + filter - 1, TYPE_3BYTE_BGR);


        for (int i = 0; i < out.getWidth(); i++) {
            for (int j = 0; j < out.getHeight(); j++) {
                if (i <= (filter - 1)/2 || i >= img.getWidth())
                    out.setRGB(i,j,0);
                else if (j <= (filter - 1)/2 || j >= img.getHeight())
                    out.setRGB(i,j,0);
                else
                    out.setRGB(i,j, img.getRGB(i - (filter - 1)/2,j - (filter - 1)/2));

            }
        }


        return out;
    }

}

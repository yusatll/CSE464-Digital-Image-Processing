package com.part2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;

public class NNClassifier {

    private double [][] trainData;
    private double [][] testData;
    private double[] eachClassSamples;
    private int[] trainClass;
    private int[] testClass;
    private int[] res;


    NNClassifier(String train, String test) throws IOException {
        trainData = new double[480][496];
        testData = new double[4320][496];
        eachClassSamples = new double[24];
        trainClass = new int[480];
        testClass = new int[4320];
        res = new int[4320];

        readFiles(train, trainData);
        readFiles(test, testData);

        //fit();
    }

    public void fit() {
        double[] max = new double[496];
        double[] min = new double[496];
        double[] acc = new double[24];

        for (int i = 0; i < 496; i++) {
            max[i] = 0.0;
            min[i] = 9999999;
            if (i<24)
                acc[i] =  0.0;
        }

        // find max and min
        for (int i = 0; i < 496; i++) {
            for (int j = 0; j < 480; j++) {
                if (trainData[j][i] > max[i])
                    max[i] = trainData[j][i];

                if (trainData[j][i] < min[i])
                    min[i] = trainData[j][i];
            }
        }

        // set min max val.
        for (int i = 0; i < 496; i++) {
            for (int j = 0; j < 480; j++) {
                if (max[i] - min[i] != 0)
                    trainData[j][i] = (trainData[j][i] - min[i])/(max[i]-min[i]);
            }

            for (int j = 0; j < 4320; j++) {
                if (max[i] - min[i] != 0)
                    testData[j][i] = (testData[j][i] - min[i])/(max[i]-min[i]);
            }
        }

        for (int i = 0; i < 4320; i++) {
            double m = 9999999;
            for (int j = 0; j < 480; j++) {
                double l2 = L2D(testData[i], trainData[j]);
                if (l2 < m){
                    m = l2;
                    res[i] = trainClass[j];
                }
            }
        }

        NumberFormat nfa = NumberFormat.getInstance();
        nfa.setMaximumFractionDigits(4);
        nfa.setMinimumFractionDigits(4);
        NumberFormat nfi = NumberFormat.getInstance();
        nfi.setMinimumIntegerDigits(2);
        nfi.setMaximumIntegerDigits(2);

        System.out.println("Finding Accuracies");
        for (int i = 0; i < testClass.length; i++) {
            if (testClass[i] == res[i])
                ++acc[testClass[i]];
        }

        for (int i = 0; i < 24; i++) {
            acc[i] = acc[i] / eachClassSamples[i];
            System.out.println("Class " + nfi.format(i) + "  Accuracy: " + nfa.format(acc[i]));
        }

        double avrAcc = 0.0;

        for (int i = 0; i < acc.length; i++) {
            avrAcc += acc[i];
        }

        avrAcc = avrAcc / acc.length;
        System.out.println("Accuracy Average: "+nfa.format(avrAcc));

    }

    private double L2D(double[] testClass, double[] trainDatum) {
        double dist = 0.0;
        if (testClass.length != trainDatum.length)
            return -1;
        for (int i = 0; i < testClass.length; i++) {
            dist += Math.abs(testClass[i] - trainDatum[i]);
        }
        return dist;
    }


    private void readFiles(String file, double[][] data) throws IOException {

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(file));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        String[] names = file.split("/");
        String filename = names[2];
        System.out.println("Read Patterns From " + filename + " File");

        for (int i = 0; i < data.length; i++) {
            String line = br.readLine();
            String[] columnOfLine = line.split(", ");
            // traindata
            if (data.length == 480) {
                for (int j = 0; j < 496; j++) {
                    trainData[i][j] = Double.parseDouble(columnOfLine[j]);
                }
                trainClass[i] = Integer.parseInt(columnOfLine[496].replaceAll(" ",
                ""));
            }
            // test data
            else if (data.length == 4320) // test txt
            {
                for (int j = 0; j < 496; j++) {
                    testData[i][j] = Double.parseDouble(columnOfLine[j]);
                }
                testClass[i] = Integer.parseInt(columnOfLine[496].replaceAll(" ",""));
                ++eachClassSamples[testClass[i]];
            }

        }
    }
}

package com.part2;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        String dataset = "Outex_TC_00012/001/";
        Features f= new Features();
        f.writeFeaturesToFile(dataset);
        NNClassifier nnc = new NNClassifier(dataset+"train_pattern.txt",dataset+"test_pattern.txt");
        nnc.fit();
    }
}

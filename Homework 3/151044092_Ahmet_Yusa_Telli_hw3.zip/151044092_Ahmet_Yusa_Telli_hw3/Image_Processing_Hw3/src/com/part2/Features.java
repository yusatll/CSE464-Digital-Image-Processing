package com.part2;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Features {

    public void writeFeaturesToFile(String filePath) throws IOException {
        BufferedReader train = Files.newBufferedReader(Paths.get(filePath + "train.txt"));
        BufferedReader test = Files.newBufferedReader(Paths.get(filePath + "test.txt"));

        Pattern trainPattern = new Pattern(filePath + "train_pattern.txt");
        Pattern testPattern = new Pattern(filePath + "test_pattern.txt");

        System.out.println("Finding train.txt Features");
        extract(train,trainPattern);
        System.out.println("Finding test.txt Features");
        extract(test,testPattern);

        train.close();
        test.close();
    }

    private void extract(BufferedReader br, Pattern p) throws IOException {
        String linecount = br.readLine();
        String line = null;
        while ((line = br.readLine()) != null) {
            String[] img = line.split(" ");
            String path = "Outex_TC_00012/images/" + img[0];
            BufferedImage image = ImageIO.read(new File(path));
            HistogramEqualization histEq = new HistogramEqualization(image, 5);
            BufferedImage equalized = histEq.HistEqualImage();
            p.setImage(equalized, img[1]);
            p.run();
        }
        System.out.println("Pattern Created");
    }
}

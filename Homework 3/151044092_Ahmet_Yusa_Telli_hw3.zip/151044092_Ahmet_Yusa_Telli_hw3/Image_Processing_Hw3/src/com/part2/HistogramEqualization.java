package com.part2;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

public class HistogramEqualization {

    HistogramEqualization(BufferedImage img, int filter_size)
    {
        this.image = img;
        this.size = filter_size;
        this.imageRaster = image.getRaster();
    }

    public BufferedImage HistEqualImage()
    {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage histImg = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        WritableRaster histRaster = histImg.getRaster();

        int half = size / 2;
        double total = 0.0;
        for (int i = half; i < width - half; i++) {
            for (int j = half; j < height - half; j++) {
                for (int k = 0; k < size; k++) {
                    for (int l = 0; l < size; l++) {
                        total += (imageRaster.getSample(i-k+half, j-l+half, 0) / 255.0);
                    }
                }
                histRaster.setSample(i, j,0, equalize(size, total));
                total = 0.0;
            }
        }

        histImg.setData(histRaster);
        return histImg;
    }

    private int equalize(int s, double t)
    {
        return (int) ((Math.pow(2, s)-1) * t);
    }

    private BufferedImage image;
    private WritableRaster imageRaster;
    private int size;

}

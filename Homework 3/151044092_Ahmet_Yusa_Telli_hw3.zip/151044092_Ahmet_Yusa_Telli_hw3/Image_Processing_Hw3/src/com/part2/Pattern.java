package com.part2;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.FileWriter;
import java.io.IOException;

public class Pattern {

    private FileWriter fw;
    private BufferedImage image = null;
    private int[][] features;
    private String classFeature;

    public Pattern(String s) throws IOException {
        fw = new FileWriter(s);
    }

    public void setImage(BufferedImage equalized, String feature) {
        this.image = equalized;
        this.classFeature = feature;
        this.features = new int[equalized.getWidth()-2][equalized.getHeight()-2];
        for (int i = 0; i < image.getWidth()-2; i++) {
            for (int j = 0; j < image.getHeight()-2; j++) {
                features[i][j] = 0;
            }
        }
    }

    public void run() throws IOException {
        WritableRaster imgRaster = this.image.getRaster();
        int total = 0;

        for (int i = 1; i < this.image.getWidth()-1; i++) {
            for (int j = 1; j < this.image.getHeight()-1; j++) {
                total  = 0;
                for (int k = 0; k < 3; k++) {
                    for (int l = 0; l < 3; l++) {
                        int sample1 = imgRaster.getSample(i, j, 0);
                        int sample2 = imgRaster.getSample(i-k+1, j-l+1, 0);
                        int s = sample1 - sample2;
                        if (s >= 0)
                            s = 1;
                        else
                            s = 0;
                        total += s*(int) Math.pow(2, k*3+l);
                    }
                }
                features[i-1][j-1] = total;
            }
        }


        int max = 0, min = Integer.MAX_VALUE;

        for (int i = 0; i < features.length; i++) {
            for (int j = 0; j < features[i].length; j++) {
                min = Math.min(min, features[i][j]);
                max = Math.max(max, features[i][j]);
            }
        }

        // create images historgram
        int [] hist = new int[max+1];
        for (int i = 0; i < features.length; i++) {
            for (int j = 0; j < features[i].length; j++) {
                hist[features[i][j]] += 1;
            }
        }

        for (int i = 16; i < hist.length; i++) {
            fw.append(hist[i]+", ");
        }

        fw.append(classFeature).append("\n");
        fw.flush();
    }
}

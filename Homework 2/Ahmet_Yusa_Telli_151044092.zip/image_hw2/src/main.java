import vpt.Image;
import vpt.algorithms.display.Display2D;
import vpt.algorithms.io.Load;
import vpt.algorithms.io.Save;

public class main {
    public static void main(String[] args) {
        // Load input image
        Image img = Load.invoke("normal_image.png");
        Display2D.invoke(img,"Input Normal Image");
        // Load Binary Image
        Image binary_img = Load.invoke("binary_image.png");
        Display2D.invoke(binary_img,"Input Binary Image");

        Hw2_Class yusa = new Hw2_Class();
        yusa.PathOpeningFinder(img,true);
        yusa.PathOpeningFinder(binary_img, false);
    }
}
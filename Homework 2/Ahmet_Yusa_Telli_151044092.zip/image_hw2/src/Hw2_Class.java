import vpt.Image;
import vpt.algorithms.display.Display2D;
import vpt.algorithms.mm.binary.BDilation;
import vpt.algorithms.mm.binary.BErosion;
import vpt.algorithms.mm.binary.path.BPathOpening;
import vpt.algorithms.mm.gray.GDilation;
import vpt.algorithms.mm.gray.GErosion;
import vpt.algorithms.mm.gray.path.GPathOpening;
import vpt.util.se.FlatSE;


public class Hw2_Class implements Hw2_Interface {
    boolean changeType = false;
    @Override
    public void NegativeImage(Image img) {
        for (int i = 0; i < img.getXDim(); i++)
        {
            for (int j = 0; j < img.getYDim(); j++)
            {
                int b = img.getXYByte(i, j);
                img.setXYByte(i,j,255-b);
            }
        }
    }

    @Override
    public Image CheckImageBackground(Image img) {
        // img önceden değiştirilmişse bir daha değiştirilecek
        if (changeType){
            NegativeImage(img);
            changeType = false;
            return img;
        }
        int black = 0, white = 0;
        // sol en üst ve sol en alt taraftan başlayıp sağ tarafa doğru
        // pixel değerlerini sayar
        for (int i = 0; i < 50; i++) {
            for (int j = 0; j < img.getYDim(); j++) {
                int up = img.getXYByte(i,j);
                int down = img.getXYByte(img.getXDim() - i - 1, j);
                // x: 128-0  128-1  128-2 yukarı doğru çıkacak.
                if (up > 127 || down > 127)
                    white++;
                if (up < 127 || down < 127)
                    black++;
            }
        }
        // sol üstten aşağı doğru pixelleri kontrol ediyor.
        // ve sağ alttan başlayıp sağ yukarı gidecek
        for (int i = 0; i < img.getXDim(); i++) {
            for (int j = 0; j < 50; j++) {
                int up = img.getXYByte(i,j);
                int down = img.getXYByte(img.getXDim() - i - 1, img.getYDim() - j - 1);
                // x: 128-0  128-1  128-2
                // y: 128-0  128-1  128-2
                if (up > 127 || down > 127)
                    white++;
                if (up < 127 || down < 127)
                    black++;
            }
        }
        if (white > black) {
            NegativeImage(img);
            changeType = true;
        }
        return img;
    }

    @Override
    public void PathOpeningFinder(Image img, boolean type) {
        // her pixelin değeri verilen sayı kadar azaltıyor.
        // Image hminima = GHMinima.invoke(img,30);

        img = this.CheckImageBackground(img);
        Image result, eroded;
        // Path Opening
        if (type) {
            // Normal Image
            result = GPathOpening.invoke(img, 80);
            // Dilation
            Image dilated = GDilation.invoke(result, FlatSE.square(3));
            // Erosion
            eroded = GErosion.invoke(dilated,FlatSE.square(3));
            img = this.CheckImageBackground(eroded);
            Display2D.invoke(img,"Path Opening Normal Image Result");
        }
        else {
            // Binary Image
            result = BPathOpening.invoke(img, 60);
            // Dilation
            Image dilated = BDilation.invoke(result, FlatSE.square(3));
            // Erosion
            eroded = BErosion.invoke(dilated,FlatSE.square(3));
            img = this.CheckImageBackground(eroded);
            Display2D.invoke(img,"Path Opening Binary Image Result");
        }

    }
}

import vpt.Image;

public interface Hw2_Interface {
    void NegativeImage(Image img);
    Image CheckImageBackground(Image img);
    void PathOpeningFinder(Image img, boolean type);
}
